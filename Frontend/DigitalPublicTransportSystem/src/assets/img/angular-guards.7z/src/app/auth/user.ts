export class User {
    username: string;
    password: string;
    grant_type: string;
  }
  